

<?php $__env->startSection('content'); ?>
    <h1>Editar Livro</h1>

    <form action="<?php echo e(route('livros.update', $livro->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="titulo" class="form-label">Título</label>
            <input type="text" class="form-control" id="titulo" name="titulo" value="<?php echo e(old('titulo', $livro->titulo)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="autor" class="form-label">Autor</label>
            <input type="text" class="form-control" id="autor" name="autor" value="<?php echo e(old('autor', $livro->autor)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="ano_publicacao" class="form-label">Ano de Publicação</label>
            <input type="number" class="form-control" id="ano_publicacao" name="ano_publicacao" value="<?php echo e(old('ano_publicacao', $livro->ano_publicacao)); ?>" required>
        </div>

        <div class="mb-3">
            <label for="resumo" class="form-label">Resumo</label>
            <textarea class="form-control" id="resumo" name="resumo"><?php echo e(old('resumo', $livro->resumo)); ?></textarea>
        </div>

        <button type="submit" class="btn btn-success">Atualizar Livro</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projeto\biblioteca\resources\views/livros/editar.blade.php ENDPATH**/ ?>