<?php $__env->startSection('content'); ?>
    <div class="container-fluid d-flex justify-content-center align-items-center" style="height: 100vh; background-color: #f4f7fa;">
        <div class="text-center p-5 rounded" style="background-color: #ffffff; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
            <h1 class="display-4 text-primary mb-4">Bem-vindo à Biblioteca Virtual</h1>
            <p class="lead mb-4">Explore e gerencie sua coleção de livros de forma simples e eficiente. Cadastre novos livros e visualise sua lista a qualquer momento.</p>

            <a href="/livros" class="btn btn-primary btn-lg mb-2">Ver Livros</a>
            <a href="/livros/adicionar" class="btn btn-success btn-lg">Adicionar Novo Livro</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projeto\biblioteca\resources\views/welcome.blade.php ENDPATH**/ ?>