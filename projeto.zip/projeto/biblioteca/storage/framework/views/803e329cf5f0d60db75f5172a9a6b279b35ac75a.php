

<?php $__env->startSection('content'); ?>
    <h1>Lista de Livros</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success mt-3">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <a href="/livros/adicionar" class="btn btn-primary mb-3">Adicionar Novo Livro</a>

    <ul class="list-group">
        <?php $__currentLoopData = $livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <h5><?php echo e($livro->titulo); ?> - <?php echo e($livro->autor); ?></h5>
                    <p><?php echo e($livro->resumo); ?></p>
                    <small>Publicado em: <?php echo e($livro->ano_publicacao); ?></small>
                </div>

                <div>
                    <a href="<?php echo e(route('livros.edit', $livro->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                    <form action="<?php echo e(route('livros.destroy', $livro->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este livro?')">Excluir</button>
                    </form>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projeto\biblioteca\resources\views/livros/index.blade.php ENDPATH**/ ?>