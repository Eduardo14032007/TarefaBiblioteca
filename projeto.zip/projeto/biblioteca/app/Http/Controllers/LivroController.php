<?php

namespace App\Http\Controllers;

use App\Models\Livro;
use Illuminate\Http\Request;

class LivroController extends Controller
{
    // Lista todos os livros
    public function index()
    {
        $livros = Livro::all();
        return view('livros.index', compact('livros'));
    }

    // Exibe o formulário para adicionar um novo livro
    public function create()
    {
        return view('livros.adicionar');
    }

    // Salva um novo livro no banco de dados
    public function store(Request $request)
    {
        $request->validate([
            'titulo' => 'required|max:100',
            'autor' => 'required|max:50',
            'ano_publicacao' => 'required|integer',
            'resumo' => 'nullable|string',
        ]);

        Livro::create($request->all());

        return redirect()->route('livros.index')->with('success', 'Livro adicionado com sucesso!');
    }

    // Exibe o formulário para editar um livro existente
    public function edit(Livro $livro)
    {
        return view('livros.editar', compact('livro'));
    }

    // Atualiza os dados de um livro no banco
    public function update(Request $request, Livro $livro)
    {
        $request->validate([
            'titulo' => 'required|max:100',
            'autor' => 'required|max:50',
            'ano_publicacao' => 'required|integer',
            'resumo' => 'nullable|string',
        ]);

        $livro->update($request->all());

        return redirect()->route('livros.index')->with('success', 'Livro atualizado com sucesso!');
    }

    // Exclui um livro do banco de dados
    public function destroy(Livro $livro)
    {
        $livro->delete();

        return redirect()->route('livros.index')->with('success', 'Livro excluído com sucesso!');
    }
}
