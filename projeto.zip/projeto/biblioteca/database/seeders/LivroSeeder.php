<?php

namespace Database\Seeders;

use App\Models\Livro;
use Illuminate\Database\Seeder;

class LivroSeeder extends Seeder
{
    public function run()
    {
        Livro::create([
            'titulo' => 'O Senhor dos Anéis',
            'autor' => 'J.R.R. Tolkien',
            'ano_publicacao' => 1954,
            'resumo' => 'Uma aventura épica pela Terra Média.',
        ]);

        Livro::create([
            'titulo' => '1984',
            'autor' => 'George Orwell',
            'ano_publicacao' => 1949,
            'resumo' => 'Distopia sobre um regime totalitário.',
        ]);

        Livro::create([
            'titulo' => 'Dom Casmurro',
            'autor' => 'Machado de Assis',
            'ano_publicacao' => 1899,
            'resumo' => 'A história de Bentinho e Capitu, cheia de ambiguidades.',
        ]);

        Livro::create([
            'titulo' => 'O Pequeno Príncipe',
            'autor' => 'Antoine de Saint-Exupéry',
            'ano_publicacao' => 1943,
            'resumo' => 'Fábula sobre a infância e as relações humanas.',
        ]);

        Livro::create([
            'titulo' => 'Harry Potter e a Pedra Filosofal',
            'autor' => 'J.K. Rowling',
            'ano_publicacao' => 1997,
            'resumo' => 'A jornada de Harry Potter no mundo da magia.',
        ]);
    }
}

