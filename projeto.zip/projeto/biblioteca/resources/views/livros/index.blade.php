@extends('layouts.app')

@section('content')
    <h1>Lista de Livros</h1>

    @if(session('success'))
        <div class="alert alert-success mt-3">
            {{ session('success') }}
        </div>
    @endif

    <a href="/livros/adicionar" class="btn btn-primary mb-3">Adicionar Novo Livro</a>

    <ul class="list-group">
        @foreach ($livros as $livro)
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                    <h5>{{ $livro->titulo }} - {{ $livro->autor }}</h5>
                    <p>{{ $livro->resumo }}</p>
                    <small>Publicado em: {{ $livro->ano_publicacao }}</small>
                </div>

                <div>
                    <a href="{{ route('livros.edit', $livro->id) }}" class="btn btn-warning btn-sm">Editar</a>
                    <form action="{{ route('livros.destroy', $livro->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este livro?')">Excluir</button>
                    </form>
                </div>
            </li>
        @endforeach
    </ul>
@endsection
